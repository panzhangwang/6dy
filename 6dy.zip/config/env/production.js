'use strict';

/**
 * Expose
 */

module.exports = {
  db: process.env.MONGODB_URL
};
